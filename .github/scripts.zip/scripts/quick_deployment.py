import argparse
import os
import re
import shutil
import subprocess
import sys
import pyfiglet
from jinja2 import Template
import requests
import logging
from pathlib import Path
from ruamel.yaml import YAML
from colorama import Fore, Style


class VaultManager:
    def __init__(self, role_id, secret_id, env, name, suscription):
        self.role_id = role_id
        self.secret_id = secret_id
        self.env = env
        self.name = name
        self.suscription = suscription
        self.domain_yape3 = "https://vault.yape.tech" if env == "prd" else f"https://vault.{self.env}.yape.tech"
        self.domain_yape3mp = "https://vault.yapemarket.tech" if env == "prd" else f"https://vault.{self.env}.yapemarket.tech"

    @staticmethod
    def _get_vault_token(role_id, secret_id, suscription, domain_yape3, domain_yape3mp):
        if suscription == "yape3":
            url = f"{domain_yape3}/v1/auth/approle/login"
        else:
            url = f"{domain_yape3mp}/v1/auth/approle/login"
        data = {"role_id": role_id, "secret_id": secret_id}
        response = requests.post(url, json=data)
        if response.status_code == 200:
            return response.json()["auth"]["client_token"]
        else:
            logger.error(f"Error al obtener el token de Vault: {response.text}")
            return None

    def create_secret(self):
        list_path = ["vars", "secrets"]
        token = self._get_vault_token(self.role_id, self.secret_id, self.suscription, self.domain_yape3, self.domain_yape3mp)
        for type_vault in list_path:
            if token:
                if self.suscription == "yape3":
                    url = f"{self.domain_yape3}/v1/app_envs/data/{self.name}/{type_vault}"
                else:
                    url = f"{self.domain_yape3mp}/v1/app_envs/data/{self.name}/{type_vault}"
                headers = {"X-Vault-Token": token}
                response = requests.post(url, headers=headers, json={"data": {}})
                if response.status_code == 200:
                    logger.info(f"El secreto '{url}' ha sido creado.")
                else:
                    logger.warning(f"Verificar si el secreto '{url}' ha sido creado; de lo contrario, revisar los permisos del rol approle.")
                    # sys.exit(1)


class TemplateMerger:
    def __init__(self, template_dirs, output_dir, common_values):
        self.template_dirs = template_dirs
        self.output_dir = output_dir
        self.common_values = common_values
        self.merged_files = set()

    def merge(self):
        os.makedirs(self.output_dir, exist_ok=True)
        for template_dir in self.template_dirs:
            for root, _, files in os.walk(template_dir):
                for file in files:
                    self._merge_file(root, file, template_dir)

    def _merge_file(self, root, file, template_dir):
        template_file = os.path.join(root, file)
        relative_path = os.path.relpath(template_file, template_dir)
        output_file = os.path.join(self.output_dir, relative_path)
        rendered = self._render_template(template_file)
        self._write_output(output_file, rendered)

    def _render_template(self, template_file):
        with open(template_file, "r") as f:
            template_str = f.read()
        template = Template(template_str)
        return template.render(self.common_values)

    def _write_output(self, output_file, rendered):
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        if output_file in self.merged_files:
            with open(output_file, "a") as out_f:
                out_f.write("\n" + rendered)
        else:
            with open(output_file, "w") as out_f:
                out_f.write(rendered)
            self.merged_files.add(output_file)


class FileManager:
    @staticmethod
    def copy_files(origen, destino):
        destino_final = os.path.join(destino, os.path.basename(origen))
        if os.path.exists(destino) and os.path.isdir(destino):
            shutil.copytree(origen, destino_final, dirs_exist_ok=True)
            logger.info(f"Carpeta '{origen}' copiada a '{destino_final}'.")
        else:
            logger.error(f"El destino '{destino}' no existe o no es una carpeta.")

    @staticmethod
    def replace_squad_name(file_path, squad_name):
        with open(file_path, "r") as archivo:
            contenido = archivo.read()

        contenido_modificado = contenido.replace("{{squad_name}}", squad_name)

        with open(file_path, "w") as archivo:
            archivo.write(contenido_modificado)

        logger.info(f"El nombre del squad en '{file_path}' ha sido reemplazado por '{squad_name}'.")

    @staticmethod
    def clear_folder(folder):
        if os.path.exists(folder) and os.path.isdir(folder):
            for element in os.listdir(folder):
                element_path = os.path.join(folder, element)
                if os.path.isfile(element_path) or os.path.islink(element_path):
                    os.remove(element_path)
                elif os.path.isdir(element_path):
                    shutil.rmtree(element_path)
            logger.info(f"Se ha vaciado la carpeta '{folder}'.")
        else:
            logger.error(f"La carpeta '{folder}' no existe.")

    @staticmethod
    def verificar_archivos(file_list, search_words):
        for archivo in file_list:
            if os.path.exists(archivo):
                logger.info(f"El archivo '{archivo}' existe.")
                with open(archivo, "r") as file:
                    contenido = file.read()
                    for word in search_words:
                        if word in contenido:
                            logger.error(f"Se encontro '{word}' en el archivo '{archivo}'.")
                            print(f"::error::File '{archivo}', the word '{word}' is present and needs to be modified by your service.")
                            sys.exit(1)
            else:
                logger.error(f"El archivo '{archivo}' no existe.")
                print(f"::error::File does not exist {archivo}.")
                if archivo != "../repo_service/rules.tsv":
                    sys.exit(1)
                else:
                    print(f"::error::Revisar por qué no se configuró OWASP en el repositorio. 👀 👀 👀 👀")


class TerraformManager:
    def __init__(self, env, squad, name, services, suscription):
        self.env = env
        self.squad = squad
        self.name = name
        self.services = services
        self.suscription = suscription
        self.folder_path_terraform = "terraform/apps/squads"
        self.folder_path_terragrunt = f"terragrunt/{env}/eastus/squads/{squad}"

    def create_terraform_files(self):

        common_values = {
            "name_service": self.name,
            "squad_name": self.squad,
            "name_service_hyphen": self.name.replace("_", "-"),
            "name_service_full": args.service_name,
        }

        template_dirs = ["template/infrastructure/globaldata"]
        for service in self.services:
            logger.info(f"Agregando Servicio: {service}")
            template_dirs.append(f"template/infrastructure/{service}")

        output_dir = f"{self.folder_path_terraform}/{self.squad}/{self.name}"

        merger = TemplateMerger(template_dirs, output_dir, common_values)
        merger.merge()
        subprocess.run(["terraform", "fmt", "-recursive"], cwd=output_dir)
        logger.info("Archivos generados exitosamente y formateados.")

    def check_path(self):
        terraform_squad_path = f"{self.folder_path_terraform}/{self.squad}"
        if not os.path.exists(terraform_squad_path):
            if self.env == "qa":
                os.makedirs(terraform_squad_path)
                logger.info(f"El Squad '{terraform_squad_path}' ha sido creado.")
                logger.info(f"Creando archivos de Core para el Squad '{terraform_squad_path}'")
                FileManager.copy_files("template/infrastructure/core", terraform_squad_path)
            else:
                logger.error(f"El Squad '{terraform_squad_path}' no existe y no se creará en el entorno '{self.env}'.")

        if self.env == "qa":
            service_path = os.path.join(terraform_squad_path, self.name)
            if not os.path.exists(service_path) and self.services:
                os.makedirs(service_path)
                logger.info(f"Creando la carpeta del servicio '{service_path}'")
            if self.services:
                logger.info(f"Copiando archivos de Terraform para el servicio '{service_path}'")
                self.create_terraform_files()
        terragrunt_squad_path = self.folder_path_terragrunt

        self.setup_terragrunt_core(terragrunt_squad_path)
        self.setup_terragrunt_service(terragrunt_squad_path, self.name)
        self.setup_terraform_main()
        self.setup_tfvars()
        self.setup_workflow()
        self.prometheus_health()

    def setup_terragrunt_core(self, squad_path):
        core_path = os.path.join(squad_path, "core")
        if not os.path.exists(core_path):
            os.makedirs(core_path)
            logger.info(f"La carpeta '{core_path}' ha sido creada.")
        terragrunt_core_hcl = os.path.join(core_path, "terragrunt.hcl")
        if not os.path.exists(terragrunt_core_hcl):
            shutil.copy("template/terragrunt/service/terragrunt.hcl", terragrunt_core_hcl)
            FileManager.replace_squad_name(terragrunt_core_hcl, self.squad)
            logger.info(f"El archivo '{terragrunt_core_hcl}' ha sido creado.")
        else:
            logger.info(f"El archivo '{terragrunt_core_hcl}' ya existe.")

    def setup_terragrunt_service(self, squad_path, service_name):
        service_path = os.path.join(squad_path, service_name)
        if args.infra_services:
            if not os.path.exists(service_path):
                os.makedirs(service_path)
                logger.info(f"La carpeta '{service_path}' ha sido creada.")
            terragrunt_service_hcl = os.path.join(service_path, "terragrunt.hcl")
            if not os.path.exists(terragrunt_service_hcl):
                shutil.copy("template/terragrunt/service/terragrunt.hcl", terragrunt_service_hcl)
                # FileManager.replace_squad_name(terragrunt_service_hcl, self.squad)
                logger.info(f"El archivo '{terragrunt_service_hcl}' ha sido creado.")
            else:
                logger.info(f"El archivo '{terragrunt_service_hcl}' ya existe.")

    def setup_terraform_main(self):
        terraform_main = f"terraform/tfvars/squads/{self.squad}.tfvars"
        if not os.path.exists(terraform_main):
            Path(terraform_main).touch()
            logger.info(f"El archivo '{terraform_main}' ha sido creado.")

    def setup_tfvars(self):
        tfvars_file = f".github/workflows/terragrunt.yaml"
        if not os.path.exists(tfvars_file):
            open(tfvars_file, "a").close()
            logger.info(f"El archivo '{tfvars_file}' ha sido creado.")

    def setup_workflow(self):
        logger.debug(f"setup_workflow(): services={self.services}")  # always log

        tfvars_file = ".github/workflows/terragrunt.yaml"
        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.indent(mapping=2, sequence=4, offset=2)

        if not os.path.exists(tfvars_file):
            open(tfvars_file, "a").close()
            logger.info(f"The file '{tfvars_file}' has been created (it was missing).")

        with open(tfvars_file, "r", encoding="utf-8") as file:
            content = file.read()

        has_run_name = "run-name:" in content
        if has_run_name:
            try:
                before_run_name, after_run_name = content.split("run-name:", 1)
            except ValueError:
                logger.warning("Could not split by 'run-name:' even though it was present. Continuing without preserving it.")
                before_run_name, after_run_name = content, None
        else:
            before_run_name, after_run_name = content, None

        try:
            workflow = yaml.load(before_run_name) if before_run_name.strip() else {}
        except Exception as e:
            logger.error(f"Failed to parse YAML in '{tfvars_file}': {e}")
            return False

        try:
            wd = workflow.get("on", {}).get("workflow_dispatch", {})
            inputs = wd.get("inputs", {})
            squad_opts = inputs.get("squad", {}).get("options", None)
            app_opts = inputs.get("app", {}).get("options", None)

            if squad_opts is None:
                logger.warning("Missing 'on.workflow_dispatch.inputs.squad.options'. Creating it…")
                workflow.setdefault("on", {}).setdefault("workflow_dispatch", {}).setdefault("inputs", {}).setdefault("squad", {})["options"] = []
                squad_opts = workflow["on"]["workflow_dispatch"]["inputs"]["squad"]["options"]

            if app_opts is None:
                logger.warning("Missing 'on.workflow_dispatch.inputs.app.options'. Creating it…")
                workflow.setdefault("on", {}).setdefault("workflow_dispatch", {}).setdefault("inputs", {}).setdefault("app", {})["options"] = []
                app_opts = workflow["on"]["workflow_dispatch"]["inputs"]["app"]["options"]

            def _sort_and_dedupe(seq, *, keep_star_end=False, label="options"):
                items = [str(x).strip() for x in seq if str(x).strip() != ""]
                has_star = "*" in items
                items = [i for i in items if i != "*"]
                items = list(dict.fromkeys(items))
                items.sort(key=lambda s: s.lower())
                if keep_star_end and has_star:
                    items.append("*")
                seq.clear()
                seq.extend(items)

            normalized_squads = [str(x).strip().lower() for x in squad_opts]
            normalized_apps = [str(x).strip().lower() for x in app_opts]
            target_squad = str(self.squad).strip()
            target_app = str(self.name).strip()

            modified = False

            if target_squad.lower() not in normalized_squads:
                squad_opts.append(target_squad)
                modified = True
                logger.info(f"Added squad '{target_squad}' to 'squad.options'.")
            else:
                logger.debug(f"[DEBUG] Squad '{target_squad}' already present.")

            if self.services:
                if target_app.lower() not in normalized_apps:
                    if "*" in app_opts:
                        star_index = list(app_opts).index("*")
                        app_opts.insert(star_index, target_app)
                        logger.info(f"Added app '{target_app}' before '*' in 'app.options'.")
                    else:
                        app_opts.append(target_app)
                        logger.info(f"Added app '{target_app}' to end of 'app.options'.")
                    modified = True
                else:
                    logger.debug(f"[DEBUG] App '{target_app}' already present.")
            else:
                logger.info("Skipping app addition: infra_services is empty.")

            before_squads = list(squad_opts)
            before_apps = list(app_opts)

            _sort_and_dedupe(squad_opts, keep_star_end=False, label="squad.options")
            _sort_and_dedupe(app_opts, keep_star_end=True, label="app.options")

            if list(squad_opts) != before_squads or list(app_opts) != before_apps:
                modified = True

            if modified:
                with open(tfvars_file, "w", encoding="utf-8") as file:
                    yaml.dump(workflow, file)
                    if after_run_name is not None:
                        file.write("run-name:" + after_run_name)
                logger.info(f"Updated '{tfvars_file}'.")
                return False
            else:
                logger.info(f"No changes in '{tfvars_file}'.")
                return True

        except Exception as e:
            logger.error(f"Error processing '{tfvars_file}': {e}")
            return False

    def read_tfvars(self, file_path):
        with open(file_path, "r") as file:
            content = file.read()
        return content

    def write_tfvars(self, file_path, content):
        with open(file_path, "w") as file:
            file.write(content)

    def add_url_to_prometheus_endpoint_checks(self, file_path, new_url):
        content = self.read_tfvars(file_path)
        pattern = r"prometheus_endpoint_checks\s*=\s*\[(.*?)\]"
        match = re.search(pattern, content, re.DOTALL)
        if match:
            urls = match.group(1).split(",")
            urls = [url.strip() for url in urls]
            if f'"{new_url}"' not in urls:
                urls.append(f'"{new_url}"')
                new_list = ",\n  ".join(urls)
                updated_content = re.sub(pattern, f"prometheus_endpoint_checks = [\n  {new_list}\n]", content, flags=re.DOTALL)
                self.write_tfvars(file_path, updated_content)
                logger.info(f"La URL '{new_url}' ha sido agregada al archivo '{file_path}'.")
                return True
            else:
                logger.info(f"La URL '{new_url}' ya existe en el archivo '{file_path}'.")
        return False

    def prometheus_health(self):
        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.allow_duplicate_keys = True
        health_file = "../repo_service/infra/helm/values.yaml"
        deploy_file = "../repo_service/.github/workflows/qa_flow.yaml"
        prometheus_file = f"terraform/apps/squads/devops/prometheus/tfvars/{self.env}/eastus.tfvars"
        health_value = None
        hostname_value = None

        if os.path.exists(health_file):
            with open(health_file, "r") as file:
                try:
                    health_path = yaml.load(file.read())
                    health_value = health_path["livenessProbe"]["httpGet"]["path"]
                except Exception as e:
                    logger.warning(f"Error loading health file '{health_file}': {e}. Skipping prometheus health check.")
                    return

        if os.path.exists(deploy_file):
            with open(deploy_file, "r") as file:
                content = file.read()
                match = re.search(r"\bhostname:\s*(\S+)", content)
                if match:
                    hostname_value = match.group(1)

        if os.path.exists(prometheus_file) and health_value and hostname_value:
            if self.suscription == "yape3":
                url_domain = (
                    f"https://{hostname_value}.yape.tech{health_value}"
                    if self.env == "prd"
                    else f"https://{hostname_value}.{self.env}.yape.tech{health_value}"
                )
            else:
                url_domain = (
                    f"https://{hostname_value}.yapemarket.tech{health_value}"
                    if self.env == "prd"
                    else f"https://{hostname_value}.{self.env}.yapemarket.tech{health_value}"
                )
            with open(prometheus_file, "r") as file:
                self.add_url_to_prometheus_endpoint_checks(prometheus_file, url_domain)


def setup_logger():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)

    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    console_handler.setFormatter(formatter)

    logger.addHandler(console_handler)

    Fore.RED = "\033[91m"
    Fore.GREEN = "\033[92m"
    Fore.YELLOW = "\033[93m"
    Style.RESET_ALL = "\033[0m"

    logging.addLevelName(logging.INFO, f"{Fore.GREEN}{logging.getLevelName(logging.INFO)}{Style.RESET_ALL}")
    logging.addLevelName(logging.ERROR, f"{Fore.RED}{logging.getLevelName(logging.ERROR)}{Style.RESET_ALL}")
    logging.addLevelName(logging.WARNING, f"{Fore.YELLOW}{logging.getLevelName(logging.WARNING)}{Style.RESET_ALL}")

    return logger


if __name__ == "__main__":
    ascii_art = pyfiglet.figlet_format("Quick Deployment v.0.1")
    print(ascii_art, flush=True)

    parser = argparse.ArgumentParser(description="Self-Service Deployment Script for Infrastructure Services")
    parser.add_argument("--service_name", help="Name Service", required=True)
    parser.add_argument("--squad", help="Name Squad", required=True)
    parser.add_argument("--env", help="Name Environment", required=True)
    parser.add_argument("--infra_services", nargs="+", help="List of services Infra")
    parser.add_argument("--suscription", help="Name suscription yape3 o yap3mp", required=True)
    parser.add_argument("--vault_roleid", help="Name roleID", required=True)
    parser.add_argument("--vault_secretid", help="Name SecretID", required=True)
    args = parser.parse_args()

    from tabulate import tabulate

    print("\nArguments:")
    table = [[arg, value] for arg, value in vars(args).items()]
    print(tabulate(table, headers=["Argument", "Value"], tablefmt="github"), end="\n\n")

    logger = setup_logger()

    required_files = [
        "../repo_service/.github/workflows/qa_flow.yaml",
        "../repo_service/.github/workflows/release.yaml",
        "../repo_service/infra/helm/values.yaml",
        "../repo_service/Dockerfile",
        "../repo_service/sonar-project.properties",
        "../repo_service/rules.tsv",
    ]
    search_words = ["msnesttemplate", "ms-nest-template"]
    FileManager.verificar_archivos(required_files, search_words)

    services = args.infra_services if args.infra_services else []
    terraform_manager = TerraformManager(
        (args.env).lower(),
        (args.squad).lower(),
        (
            (
                args.service_name[3:]
                if args.service_name.startswith("ms-")
                else (args.service_name[4:] if args.service_name.startswith("app-") else args.service_name)
            )
            .replace(f"{args.squad}-", "")
            .replace("-", "_")
        ).lower(),
        services,
        args.suscription,
    )
    terraform_manager.check_path()

    vault_manager = VaultManager(args.vault_roleid, args.vault_secretid, (args.env).lower(), args.service_name, args.suscription)
    vault_manager.create_secret()

